const color = require('./color')
const fs = require('fs')
const http = require('http')

// color.getPalette('image.jpg')
//     .then(palette => { // 1. convert to json
//         console.log(palette)
//         return {
//             json: JSON.stringify(palette),
//             // image_name: 
//         }
//     })
//     .then(pallete => {
//         // 1. create file myimg.jpg.json
//         // 2. save file to 'pallete'
//         fs.writeFile('../public/data_image/image.jpg.json', pallete.json)
//     .then(() => {
//         // dupa save
//         console.log('done')
//         })
//     })

const server = http.createServer((req, res) => {    
    if (req.url == '/image') {
        let image = fs.readFileSync(`../public/image.jpg`)
        res.write(image)
    } else if (req.url == '/data') {
        let data = fs.readFileSync('../public/data_image/image.jpg.json')
        res.write(data)
        res.end('loaded')
    } else {
        res.end('NotFound!')
    }
})

server.listen(4477)

