import React from 'react';
import MainNav from './MainNav';
import Footer from './Footer';

function App() {
  return (
    <div className="App">
      <MainNav/>
      <Footer/>
    </div>
  );
}

export default App;
