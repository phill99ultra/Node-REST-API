import React from 'react';
import {BrowserRouter as Router, Link, Route} from 'react-router-dom';
import Courrency from './Courrency';
class MainNav extends React.Component {
    render(){
        return (
            <Router>
                <nav>
                    <Link to="/courrency/eur">EURO</Link>
                    <br/>
                    <Link to="/courrency/usd">USD</Link>
                    <br/>
                    <Link to="/courrency/gbp">POUND</Link>
                </nav>  
                <hr/>
                {/* <Courrency/> */}
                <Route path="/courrency/:code" component = {Courrency}/>
                {/* <Route path="/r2" exact component = {Courrency}/>
                <Route path="/r3" exact component = {Courrency}/> */}
            </Router>
        )
    }
}
export default MainNav