import React from 'react';
import {BrowserRouter as Router, Link, Route} from 'react-router-dom';
import ContentFooter from './ContentFooter'
class Footer extends React.Component {
    render() {
        return(
            <Router>                
                <footer>
                    <Link to = "/about/info1"></Link>
                    <Link to = "/about/info2"></Link>
                </footer>
                <hr/>
                <Route path="/about/:code" component = {ContentFooter}/>
            </Router>
        )
    }
}
export default Footer