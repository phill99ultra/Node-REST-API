import React from 'react'
class ContentFooter extends React.Component {
    render() {
        console.log(this.props);
        return(
            <div>All we know about {this.props.match.params.code}</div>
        )
    }
}
export default ContentFooter