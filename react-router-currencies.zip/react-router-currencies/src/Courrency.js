import React from 'react';
import axios from 'axios';
const KEY = '5c15c9b094fb9dc21970611467b1b2a1';
const URL = `http://data.fixer.io/api/latest?access_key=${KEY}`; 
class Courrency extends React.Component {
    constructor() {
        super();
        this.state = {rates: {}};
        // componentDidMount()
        // var rate;
        var _this = this;
        axios.get(URL)
            .then(response => {
                // let code = _this.props.match.params.code;
                // rate = response.data.rates[code.toUpperCase()]
                _this.setState({rate : response.data.rates})
                // console.log(rate);
            })
    }
    render() {
        let code = this.props.match.params.code;            
        return(
            <div>Info for {code} : {this.state.rates[code.toUpperCase()]}</div>
        )
    }
}
export default Courrency;