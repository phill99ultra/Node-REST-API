// start point
const fs = require('fs');


loadData = (req, res) => {
//    const data = fs.readFileSync("./server/data.json");
//     console.log(data.toString()); 
    fs.readFile("./server/data.json", (err, data) => {
        !err ? console.log(data.toString()) && showData(data) : console.log(err)          
    });       
}

showData = (data) => {
    console.log(data)
}

loadData();