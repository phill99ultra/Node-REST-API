// utilizam modulul http
const http = require('http');
const fs = require('fs');

const obj = {status : "ok"};   

loadData = (req, res) => {
    // routes
    if (req.url == '/tasks') {
        fs.readFile("./data.json", (err, data) => {       
            res = jsonHeader(res)
            if (!err) {                
                res.end(
                    json(
                        parse(data.toString()).tasks
                    ));
            } else {            
                res.end(json(err))
            }         
        });   
    } else if (req.url == '/users') {

    }  else {
        res.end(json({status: "Not Found"}));
    }        
}
jsonHeader = res => {
    res.setHeader('Content-Type', 'application/json');
    return res
}
json = data => {
    return JSON.stringify(data)    
}
parse = data => {
    return JSON.parse(data)
}
const server = http.createServer(loadData)
server.listen('8888', () => {
    console.log('starting', obj)
})
